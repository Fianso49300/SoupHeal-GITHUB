<?php

namespace Fianso;

use pocketmine\plugin\PluginBase;
use Fianso\Items\Soup;

class Main extends PluginBase{

    public static Main $instance;

    public function onEnable(): void
    {
        self::$instance = $this;
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        $this->getResource("config.yml");

        $this->getServer()->getPluginManager()->registerEvents(new Soup(), $this);
    }

    public static function getInstance() : Main{
        return self::$instance;
    }
}