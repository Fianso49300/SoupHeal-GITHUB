<?php

namespace Fianso\Items;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\VanillaItems;

class Soup implements Listener{

    public function interact(PlayerItemUseEvent $event){
        $sender = $event->getPlayer();
        $item = $sender->getInventory()->getItemInHand();
        if ($sender->getInventory()->getItemInHand()->getId() === VanillaItems::SLIMEBALL()->getId()){
            if ($sender->getHealth() < 20){
                $sender->setHealth($sender->getHealth() + 5);
                $sender->sendPopup("§a+ 2");
                $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(ItemIds::SLIMEBALL, 0, 1));
            }
        }
    }

    public function soup(PlayerMoveEvent $event){
        $sender = $event->getPlayer();
        $soupe = 0;
        $id = ItemIds::SLIME_BALL;
        $meta = 0;
        foreach ($sender->getInventory()->getContents() as $item){
            if ($item instanceof Item && $item->getId() == $id && $item->getMeta() == $meta) $soupe += $item->getCount();
        }
        if ($soupe > 128){
            $sender->getInventory()->remove(ItemFactory::getInstance()->get(ItemIds::SLIME_BALL, 0, $soupe));
            $sender->getInventory()->addItem(ItemFactory::getInstance()->get(ItemIds::SLIME_BALL, 0, 128));
        }
    }
}